
public class Test {
 
	public static void main(String[] args)
	{
		int i=0;
		Test obj=new Test();
		i=i+1;
		i=i+1;
		/*obj.i=obj.i+1;
		obj.i=obj.i+1;*/
		System.out.println(i);
		
	}

}
