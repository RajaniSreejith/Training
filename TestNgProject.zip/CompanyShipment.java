
public class CompanyShipment extends ShipmentEntity {
	private Integer tax;
	double cost=0;

	public CompanyShipment(String name, Double weight, Integer quantity, Double transferCost, Double maxShipmentCapacity,Integer tax) {
		//fill the code
		super(name, weight, quantity, transferCost, maxShipmentCapacity);
		this.tax=tax;
	}

	public int getTax() {
		return tax;
	}

	public void setTax(int tax) {
		this.tax = tax;
	}
	
	public void calculateCost(){
		//fill the code
		double total=weight*quantity*transferCost;
		cost=total+(total*tax/100);
		System.out.println("Cost for the shipment is "+cost);
	}
	
	public void operatingCapacity(){
		//fill the code
		double cost1=transferCost*maxShipmentCapacity;
		if(cost<cost1)
			System.out.println("The shipment is within the shipping capacity of the company");
		else
			System.out.println("The shipment is not within the shipping capacity of the company");
	}
}
