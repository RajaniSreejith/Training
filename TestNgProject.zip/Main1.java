import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.sql.Date;

//fill code here
public class Main1 {
	public static void main(String args[]) throws IOException, ParseException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));;
		//fill code here
		System.out.println("Enter the cheque details");
		//fill code here
		System.out.println("Enter the bank name :");
		String bank=br.readLine();
		//fill code here
		System.out.println("Enter the cheque number :");
		//fill code here
		String chq=br.readLine();
				
		System.out.println("Enter the cheque date :");
		//fill code here
		 String dateFormat = "dd/MM/yyyy";
		Date date1=new SimpleDateFormat(dateFormat).parse(br.readLine());
		Cheque obj=new Cheque(bank,chq,date1);
		PaymentBO obj1=new PaymentBO();
		try {
		obj1.processPayment(obj);
		}catch(InvalidDateException e)
		{
			
		}
	}


}
