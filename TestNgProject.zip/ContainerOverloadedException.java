
public class ContainerOverloadedException extends Exception{
    
	private static final long serialVersionUID = 1L;
	
	public ContainerOverloadedException(String msg) {
		//fill code here
		System.out.println(msg);
	}
	
}
