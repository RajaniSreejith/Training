
public class CustomerShipment extends ShipmentEntity {
	private Double referalFee;
	double cost=0;

	
	public CustomerShipment(String name, Double weight, Integer quantity, Double transferCost,
			Double maxShipmentCapacity, Double referalFee) {
		//fill the code
		super(name, weight, quantity, transferCost, maxShipmentCapacity);
		this.referalFee=referalFee;
	}

	public Double getReferalFee() {
		return referalFee;
	}

	public void setReferalFee(Double referalFee) {
		this.referalFee = referalFee;
	}

	public void calculateCost(){
		//fill the code
		cost=(weight*quantity*transferCost)+referalFee;
		System.out.println("Cost for the shipment is "+cost);
	}
	
	public void operatingCapacity(){
		//fill the code
		double cost1=transferCost*maxShipmentCapacity;
		if(cost<cost1)
			System.out.println("The shipment is within the shipping capacity of the agent");
		else
			System.out.println("The shipment is not within the shipping capacity of the agent");
	}
}