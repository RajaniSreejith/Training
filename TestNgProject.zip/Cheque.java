import java.util.Date;

//import java.sql.Date;

public class Cheque {
	private String bankName;
	private String chequeNumber;
	private Date chequeDat;
	Cheque(String bankname,String chequeNumber,java.util.Date date1)
	{
		this.bankName=bankName;
		this.chequeNumber=chequeNumber;
		this.chequeDat=(Date) date1;
	}
	public String getbankName() {
		return bankName;
	}

	public void setbankName(String bankName) {
		this.bankName = bankName;
	}
	public String chequeNumber() {
		return chequeNumber;
	}

	public void setchequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public Date getchequeDat() {
		return chequeDat;
	}

	public void setchequeDat(Date chequeDat) {
		this.chequeDat = chequeDat;
	}

}
