import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
   public static void main(String args[])throws IOException{
	  		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   System.out.println("Enter the Shipment Id ");
	   int id=Integer.parseInt(br.readLine());
			//fill code here
	   System.out.println("Enter the Shipment Name ");
	   String name=br.readLine();
	   		//fill code here
	   System.out.println("Available ports are");
	   Port[] port=new Port[4];
	   port[0]=new Port(1,"India","Chennai");
	   port[1]=new Port(2,"America","California");
	   port[2]=new Port(3,"England","London");
	   port[3]=new Port(4,"Australia","Melbourne");
			//fill code here
	   System.out.format("%-15s %-15s %s","ID","Country","PortName");
	   for(int i=0;i<port.length;i++)
	   {
		   System.out.format("%-15s %-15s %s",port[i].getId(),port[i].getCountry(),port[i].getName());
	   }
	  		//fill code here
	   System.out.println("\nEnter the arrival port name");
			//fill code here
	   String arrival=br.readLine();
	   System.out.println("Enter the departure port name");
	   		//fill code here
	   String dept=br.readLine();
	//   Shipment obj=new Shipment(id,name,arrival,dept);
   }
}

