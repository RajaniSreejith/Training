import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PaymentBO {
	
	boolean processPayment(Cheque cheque) throws InvalidDateException, ParseException
	{
		String dateFormat = "dd/MM/yyyy";
		//Date date1=new SimpleDateFormat(dateFormat).parse(br.readLine())
		Date date = new SimpleDateFormat(dateFormat).parse("15/05/2017");
		if(cheque.getchequeDat().equals(date))// || (date-cheque.getchequeDat<=90))
		{
			System.out.println("Cheque is sent to clearing house ");
		
			return true;
		}
		else 
			throw new InvalidDateException("InvalidDateException: Cheque is valid only for three months");
		
	}
}
