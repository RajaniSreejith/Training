package com.main;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Testcase {
	WebDriver driver;
	String name=null;
	  @BeforeClass
	  public void setup() {
//		driver=new FirefoxDriver();
		  System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
	  	driver = new ChromeDriver();
	  	 driver.manage().window().maximize();
	  	driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
	  	driver.get("http://apps.qa2qe.cognizant.e-box.co.in/AddressBook/");
	  }
	  
	  @Test(priority=0)
	  public void addAddressBook() {
		  System.out.println("Executing addAddress**********");
		  int random=(int) (Math.random()*1000);
		  name="Test"+random;
		  driver.findElement(By.id("nickname")).sendKeys(name);
		  driver.findElement(By.id("contact")).sendKeys("Test"+random);
		  driver.findElement(By.id("company")).sendKeys("Cognizant");
		  driver.findElement(By.id("city")).sendKeys("Bangalore");
		  driver.findElement(By.id("country")).sendKeys("India");
		  driver.findElement(By.id("type")).sendKeys("Test");
		  driver.findElement(By.id("add")).click();
	  }
	 @Test(priority=1)
	  public void updateAddressBook()
	  {
		 System.out.println("Executing updateAddress**********");
		  driver.findElement(By.id("radio0")).click();
		  driver.findElement(By.id("edit")).click();
		  driver.findElement(By.id("nickname")).sendKeys("Test");
		  driver.findElement(By.id("add")).click();
		  System.out.println("name :"+name);
		  String data=name+"Test";
		  String newdata=driver.findElement(By.xpath("//input[@id='radio0']/parent::td")).getText();
		  Assert.assertEquals(newdata,data);
	  }
	 @Test(priority=2)
	  public void deleteAddressBook() throws InterruptedException
	  {
		 System.out.println("Executing DeleteAddress**********");
		 Thread.sleep(3000);
		  driver.findElement(By.id("radio0")).click();
		  driver.findElement(By.id("delete")).click();
	  }
	  
	  @AfterTest
	  public void afterMethod() {
		  driver.quit();
	  }
}
