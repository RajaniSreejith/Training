public class ShipmentBO {
    public boolean Validate(String p1,String p2,Port[] ports) throws InvalidPortException {
		if(p1.equals(p2))
			throw new InvalidPortException("Invalid Port");
		//fill code here
		return true;
	}
    void displayShipmentDetails(Shipment shipmentObj,Port[] ports,String p1,String p2)
    {
    	String aCountry=null,dCountry=null;
    	for(int i=0;i<ports.length;i++)
    	{
    		if(ports[i].getName().equals(p1))
    			aCountry=ports[i].getCountry();
    		if(ports[i].getName().equals(p2))
    			dCountry=ports[i].getCountry();
    	}
    	System.out.format("%-15s%-15s%-15s%-15s\n", shipmentObj.getId(),shipmentObj.getName(),p1+"/"+aCountry,p2+"/"+dCountry) ;
    }
}
