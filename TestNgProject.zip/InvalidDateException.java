
public class InvalidDateException extends Exception{
	public InvalidDateException(String msg) {
		//fill code here
		System.out.println(msg);
	}
}
