
public class InvalidPortException extends Exception {
    public InvalidPortException(String str) {
		//fill code here
    	System.out.println("Invalid Port");
	}

}
